console.log('%cWelcome To The Console If You Do Not Know What You Are Doing, Close It, If You Do I Would Be Happy To Let You Develop The Website With Me infinitecodehs@gmail.com', 'color: purple; font-size: 24px; font-weight: bold;');
            console.log('%cC', `
                font-size: 100px;
                padding: 1px 35px 1px 35px;
                background-size: cover;
                border-radius:10px;
                font-family: 'Montserrat', sans-serif;
                font-weight:bold;
                color: #8BC53F;
                background-color: #121212;
            `);
 document.addEventListener('DOMContentLoaded', function () {
    const savedTitle = localStorage.getItem('pageTitle');
    if (savedTitle) {
      document.title = savedTitle;
    }
    const savedFavicon = localStorage.getItem('customFavicon');
    if (savedFavicon) {
      const favicon = document.getElementById('dynamic-favicon');
      if (favicon) {
        favicon.href = savedFavicon;
      }
    }
  });
function padlet() {
    window.open("https://padlet.com/newsomr95/chat-room-br2tjbusbebezr2n");
}
function converter() {
    window.open("https://spotidownloader.com/en")
}
function puter() {
    window.open("https://puter.com");
}
function thumbnail() {
    window.open("https://tagmp3.net/")
}
function ITU() {
    window.open("https://postimage.org/")
}